package salesianos.triana.dam.formbean;

public class LoginUsuario {

}
